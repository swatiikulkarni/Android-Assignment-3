package com.demo.admin.animations;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.demo.admin.animations.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void up(View view) {
        ImageView image = (ImageView) findViewById(R.id.imageView);
        Animation animation1 = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.down_to_up);
        image.startAnimation(animation1);
    }

    public void down(View view) {
        ImageView image = (ImageView) findViewById(R.id.imageView);
        Animation animation2 = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.up_to_down);
        image.startAnimation(animation2);
    }
    public void move(View view) {
        ImageView image = (ImageView) findViewById(R.id.imageView);
        Animation animation3 = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.left_to_right);
        image.startAnimation(animation3);
    }

    public void left(View view) {
        ImageView image = (ImageView) findViewById(R.id.imageView);
        Animation animation4 = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.right_to_left);
        image.startAnimation(animation4);
    }

}