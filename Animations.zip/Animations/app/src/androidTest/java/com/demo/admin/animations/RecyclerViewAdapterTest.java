package com.demo.admin.animations;

import static org.junit.Assert.*;

public class RecyclerViewAdapterTest {

}